// QSO Website Interactive Features
document.addEventListener('DOMContentLoaded', () => {
    console.log("QSO Platform Website Loaded Successfully!");
    
    const searchBtn = document.querySelector('.search-box button');
    const searchInput = document.querySelector('.search-box input');
    
    if (searchBtn && searchInput) {
        searchBtn.addEventListener('click', () => {
            const query = searchInput.value.trim();
            if (query) {
                alert(`Searching reviews for: ${query}`);
            } else {
                alert('Kripya search box me company ya keyword enter karein.');
            }
        });
    }
});
